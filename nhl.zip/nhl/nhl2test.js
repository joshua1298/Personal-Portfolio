

const statCache = {} //used to cache results to limit api calls, stores each standings call
let teamsArray
const testDate = "November 18, 2024"

async function run(){
    const start = performance.now();
    await getWeekNumber()
    await populateTable(4)
    const end  = performance.now()
    console.log("Time: " + ((end - start) / 1000))
}

run()

//fill the table with relevant data
async function populateTable(weeksBack){
    
    teamsArray = await calculateScores(weeksBack)
    
    //get todays standings
    let apiCall = "https://corsproxy.io/?https://api-web.nhle.com/v1/standings/2024-11-18"
    const todayStandings = await getInfo(apiCall)

    //get standings x weeks back
    apiCall = "https://corsproxy.io/?https://api-web.nhle.com/v1/standings/" + getWeeksBackDate(weeksBack)
    const pastStandings = await getInfo(apiCall)



    //fill each row
    for(let i = 0; i<32; i++){
        fillRow(i, todayStandings, pastStandings)
    }

}


async function fillRow(i, today, past){

    const teamName = teamsArray[i].name

    //current place in standings
    let currentPlace = 0
    for(let i = 0; i<32; i++){
        if(teamName === today.standings[i].teamAbbrev.default)
            currentPlace = i 
    }

    //place in standings x weeks ago
    let pastPlace = 0
    for(let i = 0; i<32; i++){
        if(teamName === past.standings[i].teamAbbrev.default)
            pastPlace = i 
    }

    //grab current row
    const row = document.querySelector(`tr[data-rank="${(i+1)}"]`)

    //assign all the rows children
    const [rank, team, score, cumuScore, gamesPlayed, wins, losses, otloss, diff] = row.children
    
    //add team picture
    team.querySelector("img").src = today.standings[currentPlace].teamLogo
    
    //build team name
    team.querySelector("span").textContent = today.standings[currentPlace].placeName.default + " " 
        + today.standings[currentPlace].teamCommonName.default

    //score column
    score.textContent = (teamsArray[i].score).toFixed(3)

    //cumuScore column I NEED TO ADD A THIRD TO KEY TO EACH TEAM OBJECT THAT DISPLAYS THIS VALUE
    cumuScore.textContent = "N/A"
    //GP column
    gamesPlayed.textContent = today.standings[currentPlace].gamesPlayed - past.standings[pastPlace].gamesPlayed

    //Wins column
    wins.textContent = today.standings[currentPlace].wins - past.standings[pastPlace].wins

    //Losses Column
    losses.textContent = today.standings[currentPlace].losses - past.standings[pastPlace].losses

    //OT losses column
    otloss.textContent = today.standings[currentPlace].otLosses - past.standings[pastPlace].otLosses
    
    //calculate goal diff of the specific time span
    let timeSpanGoalDiff = today.standings[currentPlace].goalDifferential - past.standings[pastPlace].goalDifferential

    //color text accordingly
    if(timeSpanGoalDiff > 0){
        diff.textContent = "+" + timeSpanGoalDiff
        diff.style.color = "green"
    }else if(timeSpanGoalDiff < 0){
        diff.textContent = timeSpanGoalDiff
        diff.style.color = "red"
    }

    /*Just regular NHL standings
    const row = document.querySelector(`tr[data-rank="${i}"]`)
    const [rank, team, score, lastWeekRating, gamesPlayed, wins, losses, otloss, diff] = row.children

    team.querySelector("img").src = infoObject.standings[i-1].teamLogo //picture
    team.querySelector("span").textContent = infoObject.standings[i-1].placeName.default + " " + infoObject.standings[i-1].teamCommonName.default //team name

    if(infoObject.standings[i-1].goalDifferential > 0){
        diff.textContent = "+" + infoObject.standings[i-1].goalDifferential
        diff.style.color = "green"
    }else if(infoObject.standings[i-1].goalDifferential < 0){
        diff.textContent = infoObject.standings[i-1].goalDifferential
        diff.style.color = "red"
    }

    diff.textContent = infoObject.standings[i-1].goalDifferential > -1 ? "+"+infoObject.standings[i-1].goalDifferential : infoObject.standings[i-1].goalDifferential //GD

    gamesPlayed.textContent = infoObject.standings[i-1].gamesPlayed //GP

    wins.textContent = infoObject.standings[i-1].wins
    losses.textContent = infoObject.standings[i-1].losses
    otloss.textContent = infoObject.standings[i-1].otLosses

    lastWeekRating.textContent = "N/A"
    score.textContent = "N/A"
    */
    
}

//calculate the team scores based on how many weeks back!!!!
async function calculateScores(weeksBack){
    
    const today = new Date(testDate)
    const dayIterator = new Date(testDate) //where to calculate score from based on the parameter (default is 4 weeks back)
    dayIterator.setDate(today.getDate() - (weeksBack*7)) //set dayIterator to the date that is x weeks back

    let teamArray = [] //array of each team object

    //promise mess mumbo jumbo
    const promises = [] //stores every api call

    //gets the scoreboards for each day
    for(let i = 0; i<(weeksBack * 7); i++){
        const apiCall = "https://corsproxy.io/?https://api-web.nhle.com/v1/score/" + convertDateYearFirst(dayIterator)
        promises.push(getInfo(apiCall)) //store api call into array
        dayIterator.setDate(dayIterator.getDate() + 1) //icrement iterator
    }
    dayIterator.setDate(today.getDate() - (weeksBack*7)) //set iterator back to normal


    const yesterday = new Date(dayIterator) //declare yesterday outside for loop for later access
    let yesterdayString = "" //string for api calls and caching
    //gets the standings for each day
    for(let i = 0; i<(weeksBack * 7); i++){
        yesterday.setDate(dayIterator.getDate() - 1) //sets yesterday to one day behind the iterator
        yesterdayString = convertDateYearFirst(yesterday) //gets string version
        
        const apiCall = "https://corsproxy.io/?https://api-web.nhle.com/v1/standings/" + yesterdayString
        promises.push(getInfo(apiCall)) //store api call to array

        yesterday.setDate(yesterday.getDate() + 1) //increment
    }
    yesterday.setTime(dayIterator.getTime()) //reset yesterday

    const results = await Promise.all(promises) //resolve every promise into an array
    const gamesList = [] //for each scoreboard

    //store first half of results in gameList, store second half in statCache
    for(let o = 0; o<(weeksBack * 7 * 2 ); o++){
        if(o < (weeksBack * 7)){
            gamesList[o] = results[o]
        }else{
            yesterdayString = convertDateYearFirst(yesterday)
            if(!statCache[yesterdayString]){
                statCache[yesterdayString] = results[o]
            }
            yesterday.setDate(yesterday.getDate() + 1)
        }
    }

    for(let i = 0; i<(weeksBack * 7); i++){ //iterates through every day in x weeks
        for(let j = 0; j<gamesList[i].games.length; j++){ //iterates through every game on a date
            let homeScore = 0.0
            const homeName = gamesList[i].games[j].homeTeam.abbrev

            let awayScore = 0.0
            const awayName = gamesList[i].games[j].awayTeam.abbrev

            let isOt = false
            let homeWin = true

            //check if the game is OT
            if(gamesList[i].games[j].gameOutcome.lastPeriodType != "REG"){
                isOt = true
            }

            //checks who won the game
            if(gamesList[i].games[j].awayTeam.score > gamesList[i].games[j].homeTeam.score){
                homeWin = false
            }

            //Getting base scores
            if(homeWin && !isOt){
                homeScore += 3
                awayScore -= 1
            }else if(homeWin && isOt){
                homeScore += 2
                awayScore -= 0.5
            }else if(!homeWin && !isOt){
                awayScore += 3
                homeScore -= 1
            }else if(!homeWin && isOt){
                awayScore += 2
                homeScore -= 0.5
            }

            //get last week ranks for each team
            homeScore *= await getRankModifier(dayIterator, awayName, homeWin)
            awayScore *= await getRankModifier(dayIterator, homeName, !homeWin)

            //Goal Differential calculation
            const goalDiff = Math.abs(gamesList[i].games[j].homeTeam.score - gamesList[i].games[j].awayTeam.score)
            switch(goalDiff){
                case 0:
                case 1:
                    break;
                case 2:
                    homeScore += homeWin ? 0.2 : -0.2
                    awayScore += homeWin ? -0.2 : 0.2
                    break;
                case 3:
                    homeScore += homeWin ? 0.3 : -0.3
                    awayScore += homeWin ? -0.3 : 0.3
                    break;
                default:
                    homeScore += homeWin ? 0.4 : -0.4
                    awayScore += homeWin ? -0.4 : 0.4
                    break;
            }
            
            //Home/away context bonus
            if(!homeWin){
                homeScore -= 0.2
                awayScore += 0.2
            }

            //update or add homeTeamObject
            const homeTeamObject = teamArray.find(obj => obj.name === homeName)
            if(!homeTeamObject){
                teamArray.push({
                    name: homeName,
                    score: homeScore,
                })
            }else{
                homeTeamObject.score += homeScore
            }

            //update or add awayTeamObject
            const awayTeamObject = teamArray.find(obj => obj.name === awayName)
            if(!awayTeamObject){
                teamArray.push({
                    name: awayName,
                    score: awayScore,
                })
            }else{
                awayTeamObject.score += awayScore
            }
        }
        dayIterator.setDate(dayIterator.getDate() + 1)
    }

    return teamArray.sort((a, b) => b.score - a.score)
}

//get the rank of the opponent and return the modifier
async function getRankModifier(date, opp, didWin){
    
    const yesterday = new Date(date)
    yesterday.setDate(date.getDate() - 1)
    let yesterdayString = convertDateYearFirst(yesterday)

    //cache miss
    if(!statCache[yesterdayString]){ 
        apiCall = "https://corsproxy.io/?https://api-web.nhle.com/v1/standings/" + yesterdayString
        const standings = await getInfo(apiCall)
        statCache[yesterdayString] = standings
    }
    
    const standingsObject = statCache[yesterdayString]
    
    let teamRank = 0

    //find team rank
    for(let i = 0; i<32; i++){
        if(opp === standingsObject.standings[i].teamAbbrev.default){
            teamRank = standingsObject.standings[i].leagueSequence
            break;
        }
    }

    //based on win or loss, return the correct opponent strength modifier
    if(teamRank >= 1 && teamRank <= 5)
        return didWin ? 1.2 : 0.95
    else if(teamRank >= 6 && teamRank <= 10)
        return didWin ? 1.1 : 0.95
    else if(teamRank >= 11 && teamRank <= 21)
        return 1
    else if(teamRank >= 22 && teamRank <= 27)
        return didWin ? 1 : 1.1
    else if(teamRank >= 28 && teamRank <= 32)
        return didWin ? 1 : 1.1
    else
        return "This function is broken"

}

//converts js date object format into NHL api date format (YYYY-MM-DD)
function convertDateYearFirst(date){        
    let stringDate = date.getFullYear()

    if(date.getMonth() + 1 < 10){
        stringDate += "-0" + (date.getMonth() + 1)
    }else{
        stringDate += "-" + (date.getMonth() + 1)
    }

    if(date.getDate() < 10){
        stringDate += "-0" + date.getDate()
    }else{
        stringDate += "-" + date.getDate()
    }

    return stringDate
}

//retruns the date that is X weeks back from today in NHL api format YYYY-MM-DD
function getWeeksBackDate(weeksBack){
    const today = new Date("November 11, 2024")
    const pastDate = new Date("November 11, 2024")
    pastDate.setDate(today.getDate() - (weeksBack * 7))

    return convertDateYearFirst(pastDate)
}

//updates week counter in the masthead
async function getWeekNumber(){
    
    const months = {
        0: "January",
        1: "February",
        2: "March",
        3: "April",
        4: "May",
        5: "June",
        6: "July",
        7: "August",
        8: "September",
        9: "October",
        10: "November",
        11: "December"
    }
    
    const apiCall = "https://corsproxy.io/?https://api-web.nhle.com/v1/schedule/now"
    const info = await getInfo(apiCall)

    const seasonStartYear = parseInt(info.regularSeasonStartDate)
    const seasonStartMonth = months[parseInt(info.regularSeasonStartDate.substring(5, 7)) - 1]
    const seasonStartDay = parseInt(info.regularSeasonStartDate.substring(8))
    

    const date = new Date()
    const seasonStart = new Date(seasonStartMonth+" "+seasonStartDay+", "+seasonStartYear)
    
    let counter = 0
    let weekNumber = 0
    if(date>=seasonStart){
       while(date.getMonth() != seasonStart.getMonth() || date.getDate() != seasonStart.getDate() || date.getFullYear() != seasonStart.getFullYear()){
            date.setDate(date.getDate() - 1)
            counter++
        }
        weekNumber = Math.round((counter / 7) + 0.5)
    }
    
    let week = document.getElementById("week")
    week.textContent = "Week "+weekNumber

}

async function getInfo(apiCall){
    try{
        const responsetime = await fetch(apiCall)    
        const responsetimejson = await responsetime.json()
        console.log(responsetimejson)
        return responsetimejson
    }
    catch(error){
        console.error(error)
    }
}


/*first attempt at calling api (ToT). akin to man making the harnessing fire
async function makePointsLeaders(){
    for(let i = 0; i<5; i++){
        await createPointsItem(i)
    }
}
async function createPointsItem(i){
    const newI = i+1 + ""
    const pointsInfo = await fetchPointsLeaders()
    
    const pic = document.createElement("div")
    pic.id = "headshot" + newI
    pic.className = "headshot"
    pic.style.backgroundImage = "url(" + pointsInfo.points[i].headshot + ")"
    document.getElementById("item" + newI).appendChild(pic)

    const infoBox = document.createElement("div")
    infoBox.id = "infoBox" + newI
    infoBox.className = "infoBox"
    document.getElementById("item" + newI).appendChild(infoBox)

    const namePlate = document.createElement("div")
    namePlate.id = "namePlate" + newI
    namePlate.className = "namePlate"
    namePlate.innerHTML = newI + ". " + pointsInfo.points[i].firstName.default + " " + pointsInfo.points[i].lastName.default
    document.getElementById("infoBox" + newI).appendChild(namePlate)

    pointsPlate = document.createElement("div")
    pointsPlate.id = "pointsPlate" + newI
    pointsPlate.className = "pointsPlate"
    document.getElementById("infoBox" + newI).appendChild(pointsPlate)

    const goals = document.createElement("div")
    goals.className = "pointsInfo"
    goals.innerHTML = "G<br>" + pointsInfo.goals[i].value

    const assists = document.createElement("div")
    assists.className = "pointsInfo"
    assists.innerHTML = "A<br>" + pointsInfo.assists[i].value

    const pointsTotal = document.createElement("div")
    pointsTotal.className = "pointsInfo"
    pointsTotal.innerHTML = "P<br>" + pointsInfo.points[i].value
    
    pointsPlate.appendChild(goals)
    pointsPlate.appendChild(assists)
    pointsPlate.appendChild(pointsTotal)

}

async function fetchPointsLeaders(){
    try{
        const response = await fetch("https://corsproxy.io/?https://api-web.nhle.com/v1/skater-stats-leaders/current?limit=5")
        
        if(!response.ok){
            throw new Error("response not ok")
        }

        const pointsInfo = await response.json()

        return pointsInfo
    }
    catch(error){
        console.error(error)
    }
    
} 
*/